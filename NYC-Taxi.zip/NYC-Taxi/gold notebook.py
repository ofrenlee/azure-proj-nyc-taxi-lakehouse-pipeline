# Databricks notebook source
# MAGIC %md
# MAGIC ### Data Reading, Writing, Creating - Delta Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Acess

# COMMAND ----------

# DBTITLE 1,variables
storage_account = "nyctaxistorageyaj"
client_id = dbutils.secrets.get(scope="nyc-scope", key="app-client-id")
tenant_id = dbutils.secrets.get(scope="nyc-scope", key="tenant-id")
client_secret = dbutils.secrets.get(scope="nyc-scope", key="client-secret")

# COMMAND ----------

spark.conf.set(f"fs.azure.account.auth.type.{storage_account}.dfs.core.windows.net", "OAuth")
spark.conf.set(f"fs.azure.account.oauth.provider.type.{storage_account}.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider") 
spark.conf.set(f"fs.azure.account.oauth2.client.id.{storage_account}.dfs.core.windows.net", f"{client_id}") # app-id
spark.conf.set(f"fs.azure.account.oauth2.client.secret.{storage_account}.dfs.core.windows.net", f"{client_secret}") # secret-id
spark.conf.set(f"fs.azure.account.oauth2.client.endpoint.{storage_account}.dfs.core.windows.net", f"https://login.windows.net/{tenant_id}/oauth2/token") # directory

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validate Access via dbutils.fs.ls

# COMMAND ----------

dbutils.fs.ls(f"abfss://silver@{storage_account}.dfs.core.windows.net")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Initiate PySpark libraries

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Catalog & Database/Schema Creation

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE CATALOG nyctaxi --once run only 

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE nyctaxi.gold --once run only 
# MAGIC -- CREATE SCHEMA and CREATE DATABASE are interchangeable

# COMMAND ----------

# MAGIC %md
# MAGIC ### Storage Variable

# COMMAND ----------

silver = f"abfss://silver@{storage_account}.dfs.core.windows.net/"
gold = f"abfss://gold@{storage_account}.dfs.core.windows.net/"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Trip Zone Gold

# COMMAND ----------

# MAGIC %md
# MAGIC **Data Read to df**

# COMMAND ----------

df_zone_silver = spark.read.format("parquet")\
                    .option("header", "true")\
                    .option("inferSchema", "true")\
                    .load(f"{silver}/trip_zone")

display(df_zone_silver)

# COMMAND ----------

# MAGIC %md
# MAGIC **df to Gold ADLS folder path and Table**

# COMMAND ----------

# DBTITLE 1,had to configure external location / external table
df_zone_silver.write.format("delta")\
                    .mode("overwrite")\
                    .option("path",f"{gold}/trip_zone")\
                    .saveAsTable("nyctaxi.gold.trip_zone")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM nyctaxi.gold.trip_zone

# COMMAND ----------

# MAGIC %md
# MAGIC ### Trip Type Gold

# COMMAND ----------

# MAGIC %md
# MAGIC **Data Read to df**

# COMMAND ----------

df_type_silver = spark.read.format("parquet")\
                    .option("header", "true")\
                    .option("inferSchema", "true")\
                    .load(f"{silver}/trip_type")

display(df_type_silver)

# COMMAND ----------

# MAGIC %md
# MAGIC **df to Gold ADLS folder path and Table**

# COMMAND ----------

df_type_silver.write.format("delta")\
                    .mode("overwrite")\
                    .option("path",f"{gold}/trip_type")\
                    .saveAsTable("nyctaxi.gold.trip_type")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM nyctaxi.gold.trip_type

# COMMAND ----------

# MAGIC %md
# MAGIC ### Trip Data Gold

# COMMAND ----------

# MAGIC %md
# MAGIC **Data Read to df**

# COMMAND ----------

trip_data_silver = spark.read.format("parquet")\
                    .option("header", "true")\
                    .option("inferSchema", "true")\
                    .load(f"{silver}/trip_data")

display(trip_data_silver)

# COMMAND ----------

# MAGIC %md
# MAGIC **df to Gold ADLS folder path and Table**

# COMMAND ----------

trip_data_silver.write.format("delta")\
                  .mode("overwrite")\
                  .option("path",f"{gold}/trip_data")\
                  .saveAsTable("nyctaxi.gold.trip_data")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM nyctaxi.gold.trip_data

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE EXTENDED nyctaxi.gold.trip_data

# COMMAND ----------

# MAGIC %md
# MAGIC ### Learning Delta Lake

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM nyctaxi.gold.trip_zone

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE nyctaxi.gold.trip_zone
# MAGIC SET Borough = "BMR"
# MAGIC WHERE LocationID = 1

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM nyctaxi.gold.trip_zone
# MAGIC WHERE LocationID = 1

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM nyctaxi.gold.trip_zone WHERE LocationID = 1

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM nyctaxi.gold.trip_zone
# MAGIC WHERE LocationID = 1

# COMMAND ----------

# MAGIC %md
# MAGIC **Describe History**

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY nyctaxi.gold.trip_zone

# COMMAND ----------

# MAGIC %md
# MAGIC **Time Travel with SELECT**

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM nyctaxi.gold.trip_zone VERSION AS OF 0

# COMMAND ----------

# MAGIC %md
# MAGIC **Time Travel with RESTORE**

# COMMAND ----------

# MAGIC %sql
# MAGIC RESTORE TABLE nyctaxi.gold.trip_zone TO VERSION AS OF 0

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM nyctaxi.gold.trip_zone