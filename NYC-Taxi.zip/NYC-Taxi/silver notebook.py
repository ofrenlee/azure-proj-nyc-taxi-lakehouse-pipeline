# Databricks notebook source
# MAGIC %md 
# MAGIC ## Access Data in Data Lake via Databricks

# COMMAND ----------

storage_account = "nyctaxistorageyaj"
client_id = dbutils.secrets.get(scope="nyc-scope", key="app-client-id")
tenant_id = dbutils.secrets.get(scope="nyc-scope", key="tenant-id")
client_secret = dbutils.secrets.get(scope="nyc-scope", key="client-secret")

# COMMAND ----------

spark.conf.set(f"fs.azure.account.auth.type.{storage_account}.dfs.core.windows.net", "OAuth")
spark.conf.set(f"fs.azure.account.oauth.provider.type.{storage_account}.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider") 
spark.conf.set(f"fs.azure.account.oauth2.client.id.{storage_account}.dfs.core.windows.net", f"{client_id}") # app-id
spark.conf.set(f"fs.azure.account.oauth2.client.secret.{storage_account}.dfs.core.windows.net", f"{client_secret}") # secret-id
spark.conf.set(f"fs.azure.account.oauth2.client.endpoint.{storage_account}.dfs.core.windows.net", f"https://login.windows.net/{tenant_id}/oauth2/token") # directory

# COMMAND ----------

print(storage_account,client_id,tenant_id,client_secret)

# COMMAND ----------

# DBTITLE 1,test access bronze
dbutils.fs.ls(f'abfss://bronze@{storage_account}.dfs.core.windows.net/')

# COMMAND ----------

# MAGIC %md
# MAGIC **Data is now accessible !!!**

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Reading

# COMMAND ----------

# MAGIC %md
# MAGIC **Import Libraries**

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC **Reading CSV Data** 
# MAGIC - Trip Type Data

# COMMAND ----------

df_trip_type = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load("abfss://bronze@nyctaxistorageyaj.dfs.core.windows.net/trip_type/")

# COMMAND ----------

df_trip_type.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **Reading CSV Data** 
# MAGIC - Trip Zone Data

# COMMAND ----------

df_trip_zone = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load("abfss://bronze@nyctaxistorageyaj.dfs.core.windows.net/trip_zone/")

# COMMAND ----------

df_trip_zone.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **Reading CSV Data** 
# MAGIC - Trip Data

# COMMAND ----------

# DBTITLE 1,customized schema using DDL
# run this firts before reading customized schema

my_schema = '''
    VendorID BIGINT,
    lpep_pickup_datetime TIMESTAMP,
    lpep_dropoff_datetime TIMESTAMP,
    store_and_fwd_flag STRING,
    RatecodeID BIGINT,
    PULocationID BIGINT,
    DOLocationID BIGINT,
    passenger_count BIGINT,
    trip_distance DOUBLE,
    fare_amount DOUBLE,
    extra DOUBLE,
    mta_tax DOUBLE,
    tip_amount DOUBLE,
    tolls_amount DOUBLE,
    ehail_fee DOUBLE,
    improvement_surcharge DOUBLE,
    total_amount DOUBLE,
    payment_type BIGINT,
    trip_type BIGINT,
    congestion_surcharge DOUBLE

    '''

# COMMAND ----------

df_trip = spark.read.format("parquet") \
    .schema(my_schema)\
    .option("recursiveFileLookup","true")\
    .load("abfss://bronze@nyctaxistorageyaj.dfs.core.windows.net/trip_data/")

 #.option("header","true")\ # parquet file does not need header

# COMMAND ----------

df_trip.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC **Taxi Trip Type**

# COMMAND ----------

# DBTITLE 1,display trip data
df_trip_type.display()

# COMMAND ----------

df_trip_type = df_trip_type.withColumnRenamed('trip_type', 'trip_type_id')\
                        .withColumnRenamed('description', 'trip_description')

# COMMAND ----------

df_trip_type.display()

# COMMAND ----------

df_trip_type.write.format("parquet")\
    .mode("overwrite")\
    .option("path", "abfss://silver@nyctaxistorageyaj.dfs.core.windows.net/trip_type")\
    .save()

# COMMAND ----------

# MAGIC %md
# MAGIC **Taxi Zone Type**

# COMMAND ----------

df_trip_zone.display()

# COMMAND ----------

# DBTITLE 1,change column name
df_trip_zone = df_trip_zone.withColumnRenamed('locationid', 'LocationID')\
                        .withColumnRenamed('borough', 'Borough')\
                        .withColumnRenamed('zone', 'Zone')\
                        .withColumnRenamed('service_zone', 'Service_Zone')

# COMMAND ----------

# DBTITLE 1,Ansh's code did not work for split value
# df_trip_zone.withColumn('Zone_1',split(col('Zone'), '/')[0])\
#            .withColumn('Zone_2',split(col('Zone'), '/')[1])\
#            .display()

# COMMAND ----------

# DBTITLE 1,1/2 way to split array of column (Zone)
df_trip_zone.withColumn("Temp_Zone", split(col("Zone"), "/"))\
            .withColumn("Zone_1", expr("get(Temp_Zone, 0)"))\
            .withColumn("Zone_2", expr("get(Temp_Zone, 1)"))\
            .drop("Temp_Zone","Zone")\
            .display()

# Created new Temp_Zone column in array using split(col(<column>))
# Created Zone_1 and Zone_2 columns using expr("get(<column>,<position>)"))
# Dropped Temp_Zone and Zone columns

# COMMAND ----------

# DBTITLE 1,2/2 way to split array of column (Zone)
df_trip_zone.withColumn("Zone_1", expr("get(split(Zone, '/'), 0)"))\
            .withColumn("Zone_2", expr("get(split(Zone, '/'), 1)"))\
            .display()

# COMMAND ----------

# DBTITLE 1,final code
df_trip_zone = df_trip_zone.withColumn("Temp_Zone", split(col("Zone"), "/"))\
                .withColumn("Zone_1", expr("get(Temp_Zone, 0)"))\
                .withColumn("Zone_2", expr("get(Temp_Zone, 1)"))\
                .drop("Temp_Zone","Zone")

# COMMAND ----------

# DBTITLE 1,display df_trip_zone
df_trip_zone.display()

# COMMAND ----------

# DBTITLE 1,write data in storage
df_trip_zone.write.format("parquet")\
    .mode("overwrite")\
    .option("path", "abfss://silver@nyctaxistorageyaj.dfs.core.windows.net/trip_zone/")\
    .save()

# COMMAND ----------

# MAGIC %md
# MAGIC **Trip Data**

# COMMAND ----------

df_trip.display()

# COMMAND ----------

# DBTITLE 1,date time broken to date / year / month
df_trip.withColumn('trip_date', to_date(col('lpep_pickup_datetime')))\
       .withColumn('trip_year', year(col('lpep_pickup_datetime')))\
       .withColumn('trip_month', month(col('lpep_pickup_datetime')))\
       .display()



# COMMAND ----------

df_trip = df_trip.withColumn('trip_date', to_date(col('lpep_pickup_datetime')))\
            .withColumn('trip_year', year(col('lpep_pickup_datetime')))\
            .withColumn('trip_month', month(col('lpep_pickup_datetime')))
df_trip.display()


# COMMAND ----------

# DBTITLE 1,subset of column - using SELECT
df_trip = df_trip.select('VendorID','PULocationID','DOLocationID','trip_distance','fare_amount','total_amount','trip_year', 'trip_month')

df_trip.display()

# COMMAND ----------

df_trip.write.format("parquet")\
    .mode("overwrite")\
    .option("path", "abfss://silver@nyctaxistorageyaj.dfs.core.windows.net/trip_data/")\
    .save()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Analysis

# COMMAND ----------

df_trip.display()