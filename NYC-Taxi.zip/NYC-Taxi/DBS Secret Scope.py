# Databricks notebook source
# DBTITLE 1,create dbx secret
dbutils.secrets.help()

# COMMAND ----------

dbutils.secrets.list('nyc-scope')

# COMMAND ----------

dbutils.secrets.get(scope="nyc-scope", key="app-client-id")

# COMMAND ----------

dbutils.secrets.get(scope="nyc-scope", key="tenant-id")

# COMMAND ----------

dbutils.secrets.get(scope="nyc-scope", key="client-secret")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Once configured correctly, add in Silver Notebook