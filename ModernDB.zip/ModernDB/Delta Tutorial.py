# Databricks notebook source
# MAGIC %md
# MAGIC ###Delta Table (deltatbl)

# COMMAND ----------

# MAGIC %md
# MAGIC **JSON version 0** : Create Table

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE man_cata.man_schema.deltatbl
# MAGIC --ext_cata.ext_schema.deltatbl
# MAGIC (
# MAGIC   id INT,
# MAGIC   name STRING,
# MAGIC   city STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION 'abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/deltalake/deltatbl'

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE man_cata.man_schema.deltatbl
# MAGIC --UNDROP TABLE man_cata.man_schema.deltatbl

# COMMAND ----------

# MAGIC %md
# MAGIC ###Delta Vectors

# COMMAND ----------

# MAGIC %md
# MAGIC **JSON version 1** : Disable Delta Deletion Vectors

# COMMAND ----------

# MAGIC %sql
# MAGIC -- For Delta tables
# MAGIC
# MAGIC -- CREATE TABLE <table-name> [options] TBLPROPERTIES ('delta.enableDeletionVectors' = true);
# MAGIC
# MAGIC ALTER TABLE man_cata.man_schema.deltatbl SET TBLPROPERTIES ('delta.enableDeletionVectors' = false);

# COMMAND ----------

# MAGIC %md
# MAGIC **JSON version 2** : Inserted Data to Table

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO man_cata.man_schema.deltatbl
# MAGIC VALUES 
# MAGIC (1, 'John', 'NYC'), 
# MAGIC (2, 'Jane', 'LA'), 
# MAGIC (3, 'Bob', 'SF');

# COMMAND ----------

# MAGIC %md
# MAGIC **%sql Describe Extended Command**

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE EXTENDED man_cata.man_schema.deltatbl

# COMMAND ----------

# MAGIC %sql 
# MAGIC SELECT * FROM man_cata.man_schema.deltatbl

# COMMAND ----------

# MAGIC %md
# MAGIC **JSON version 3** : Tombstoning of Files 
# MAGIC (old paruqet file outdated, new file with new set of data is used)

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE man_cata.man_schema.deltatbl
# MAGIC SET city = 'Toronto' 
# MAGIC WHERE id = 1 and name = 'John'

# COMMAND ----------

# MAGIC %sql 
# MAGIC SELECT * FROM man_cata.man_schema.deltatbl

# COMMAND ----------

# MAGIC %md
# MAGIC ### Time Travel (Data Versioning)

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY man_cata.man_schema.deltatbl

# COMMAND ----------

# MAGIC %sql
# MAGIC RESTORE man_cata.man_schema.deltatbl to VERSION AS OF 2

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY man_cata.man_schema.deltatbl

# COMMAND ----------

# MAGIC %sql 
# MAGIC SELECT * FROM man_cata.man_schema.deltatbl

# COMMAND ----------

# MAGIC %md
# MAGIC ### Deletion Vector (deltatbl2)

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC **JSON version 0** : Create Table

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE man_cata.man_schema.deltatbl2
# MAGIC --ext_cata.ext_schema.deltatbl
# MAGIC (
# MAGIC   id INT,
# MAGIC   name STRING,
# MAGIC   city STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION 'abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/deltalake/deltatbl2'

# COMMAND ----------

# MAGIC %md
# MAGIC **JSON version 1** : Enable Deletion Vectors (left deltatbl2 as enabled)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- For Delta tables
# MAGIC
# MAGIC -- CREATE TABLE <table-name> [options] TBLPROPERTIES ('delta.enableDeletionVectors' = true);
# MAGIC
# MAGIC ALTER TABLE man_cata.man_schema.deltatbl2 SET TBLPROPERTIES ('delta.enableDeletionVectors' = true);

# COMMAND ----------

# MAGIC %md
# MAGIC **JSON version 2** : Inserted Data to Table

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM man_cata.man_schema.deltatbl 
# MAGIC GROUP BY id, name, city
# MAGIC HAVING COUNT(ID) > 1
# MAGIC ORDER BY id

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO man_cata.man_schema.deltatbl2
# MAGIC VALUES 
# MAGIC (1, 'John', 'NYC'), 
# MAGIC (2, 'Jane', 'LA'), 
# MAGIC (3, 'Bob', 'SF');

# COMMAND ----------

# MAGIC %md
# MAGIC **JSON version 3** : Tombstoning of Files 
# MAGIC (old paruqet file outdated, new file with new set of data is used)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE man_cata.man_schema.deltatbl2
# MAGIC SET city = 'Seattle' 
# MAGIC WHERE id = 1 and name = 'John'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Optimize in Delta Tables 
# MAGIC - databricks auto-enabled deletion vector by default

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY man_cata.man_schema.deltatbl2

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE man_cata.man_schema.deltatbl2

# COMMAND ----------

# MAGIC %md
# MAGIC ### Deep Clone versus Shallow Clone
# MAGIC - **Deep Clone:** clones metadata and data
# MAGIC - **Shallow Clone:** clones only metadata

# COMMAND ----------

# MAGIC %md
# MAGIC **Deep Clone**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE man_cata.man_schema.deepclonetbl
# MAGIC DEEP CLONE man_cata.man_schema.deltatbl;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM man_cata.man_schema.deepclonetbl

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY man_cata.man_schema.deepclonetbl

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE EXTENDED man_cata.man_schema.deepclonetbl

# COMMAND ----------

# MAGIC %md
# MAGIC **Shallow Clone**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE man_cata.man_schema.shallowtbl
# MAGIC SHALLOW CLONE man_cata.man_schema.man_table;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM man_cata.man_schema.man_table;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE EXTENDED man_cata.man_schema.man_table;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY man_cata.man_schema.man_table;