# Databricks notebook source
print("hello yaj, i love you brother!")