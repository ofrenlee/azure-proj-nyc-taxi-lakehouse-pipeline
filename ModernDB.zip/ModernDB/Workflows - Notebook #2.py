# Databricks notebook source
print("bro, I love you too. im proud of you! maabot mo rin dreams mo ;)")