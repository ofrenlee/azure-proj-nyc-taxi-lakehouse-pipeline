# Databricks notebook source
df = spark.range(0, 1_000_000).repartition(20)

print("Partitions:", df.rdd.getNumPartitions())

df.count()

# COMMAND ----------

df = spark.range(0, 1_000_000).repartition(80)

print("Partitions:", df.rdd.getNumPartitions())

df.count()