# Databricks notebook source
# MAGIC %md
# MAGIC ### Scenario #1
# MAGIC - Managed Catalog
# MAGIC - Managed Schema
# MAGIC - Managed Table

# COMMAND ----------

# MAGIC %md
# MAGIC **Managed Catalog**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE CATALOG man_cata

# COMMAND ----------

# MAGIC %md
# MAGIC **Managed Schema / Database**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA man_cata.man_schema

# COMMAND ----------

# MAGIC %md
# MAGIC **Managed Schema / Database**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE man_cata.man_schema.man_table 
# MAGIC (
# MAGIC   id INT, 
# MAGIC   name STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC     
# MAGIC

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ### Scenario #2

# COMMAND ----------

# MAGIC %md
# MAGIC - External Catalog
# MAGIC - Managed Schema
# MAGIC - Managed Table

# COMMAND ----------

# MAGIC %md
# MAGIC **External Catalog**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE CATALOG ext_cata
# MAGIC MANAGED LOCATION 'abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/external_catalog'

# COMMAND ----------

# MAGIC %md
# MAGIC **Managed Schema**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA ext_cata.man_schema

# COMMAND ----------

# MAGIC %md
# MAGIC **Managed Table**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE ext_cata.man_schema.man_table2
# MAGIC (
# MAGIC   id INT, 
# MAGIC   name STRING
# MAGIC )
# MAGIC USING DELTA

# COMMAND ----------

# MAGIC %md
# MAGIC ### Scenario #3

# COMMAND ----------

# MAGIC %md
# MAGIC - External Catalog
# MAGIC - External Schema
# MAGIC - Managed Table

# COMMAND ----------

# MAGIC %md
# MAGIC **External Catalog**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE CATALOG ext_cata
# MAGIC MANAGED LOCATION 'abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/external_catalog'

# COMMAND ----------

# MAGIC %md
# MAGIC **Managed Schema**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA ext_cata.ext_schema
# MAGIC MANAGED LOCATION 'abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/external_schema'

# COMMAND ----------

# MAGIC %md
# MAGIC **Managed Table**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE ext_cata.ext_schema.man_table3
# MAGIC (
# MAGIC   id INT, 
# MAGIC   name STRING
# MAGIC )
# MAGIC USING DELTA

# COMMAND ----------

# MAGIC %md
# MAGIC ### Scenario #4

# COMMAND ----------

# MAGIC %md
# MAGIC - Managed Catalog
# MAGIC - Managed Schema
# MAGIC - External Table

# COMMAND ----------

# MAGIC %md
# MAGIC **External Table**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE man_cata.man_schema.ext_table
# MAGIC (
# MAGIC   id INT, 
# MAGIC   name STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION 'abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/ext_table/man_table4'

# COMMAND ----------

# MAGIC %md
# MAGIC ###Drop Managed Tables

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE man_cata.man_schema.man_table

# COMMAND ----------

# MAGIC %md
# MAGIC ###Undrop Managed Tables

# COMMAND ----------

# MAGIC %sql
# MAGIC UNDROP TABLE man_cata.man_schema.man_table

# COMMAND ----------

# MAGIC %md
# MAGIC ###Insert Into External Table

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO man_cata.man_schema.ext_table
# MAGIC VALUES 
# MAGIC (1, 'John'), 
# MAGIC (2, 'Mary'),
# MAGIC (3, 'Jane')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM man_cata.man_schema.ext_table

# COMMAND ----------

# MAGIC %md
# MAGIC ###Query Files via SELECT

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM delta.`abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/ext_table/man_table4/`
# MAGIC WHERE id = 1

# COMMAND ----------

# MAGIC %md
# MAGIC ### Permanent Views

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE VIEW man_cata.man_schema.view1
# MAGIC AS
# MAGIC SELECT * FROM delta.`abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/ext_table/man_table4/`
# MAGIC WHERE id = 1
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM man_cata.man_schema.view1 LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ###Temporary View (Not Global)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW temp_view
# MAGIC AS
# MAGIC SELECT * FROM delta.`abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/ext_table/man_table4/`
# MAGIC WHERE id = 1

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM temp_view

# COMMAND ----------

# MAGIC %md
# MAGIC ###Volumes

# COMMAND ----------

# MAGIC %md
# MAGIC **Creating Directory for Volume**

# COMMAND ----------

dbutils.fs.mkdirs ('abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/volumes')

# COMMAND ----------

# MAGIC %md
# MAGIC **Creating a Volume**

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL VOLUME man_cata.man_schema.ext_volume
# MAGIC LOCATION 'abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/volumes'

# COMMAND ----------

# MAGIC %md
# MAGIC **Dropping a Volume**

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP VOLUME man_cata.man_schema.myvolumeext

# COMMAND ----------

# MAGIC %md
# MAGIC **Copy File for Volume**

# COMMAND ----------

dbutils.fs.cp ('abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/source/Sales.csv', 'abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/volumes/Sales.csv')

# COMMAND ----------

# MAGIC %md
# MAGIC **Query Volume File**

# COMMAND ----------

# DBTITLE 1,query via UI catalog governance
# MAGIC %sql
# MAGIC SELECT * FROM cs.`Volumes/man_cata/man_schema/ext_volume/Sales.csv`

# COMMAND ----------

# DBTITLE 1,query via file path and extension
# MAGIC %sql
# MAGIC SELECT * FROM csv.`abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/volumes/Sales.csv`