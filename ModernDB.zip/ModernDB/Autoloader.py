# Databricks notebook source
# MAGIC %md
# MAGIC ### Import Pyspark Function

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### AutoLoader

# COMMAND ----------

# MAGIC %md
# MAGIC **Streaming Data Frame**

# COMMAND ----------

df = spark.readStream.format('cloudFiles')\
        .option('cloudFiles.format','parquet')\
        .option('cloudFiles.schemaLocation','abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/autoloader_sink/check')\
        .load('abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/autoloader_source')


# COMMAND ----------

df.writeStream.format('parquet')\
    .option('checkpointLocation','abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/autoloader_sink/check')\
    .trigger(processingTime = '10 seconds')\
    .start('abfss://mycontainer@storagemoderndbxyaj.dfs.core.windows.net/autoloader_sink/data')